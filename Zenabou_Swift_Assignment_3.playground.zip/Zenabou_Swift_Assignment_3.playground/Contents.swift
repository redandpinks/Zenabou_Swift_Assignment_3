import Foundation

class Ship {
    let name: String
    let year: Int
    let countryOfOrigin: String
  
    init(name: String, year: Int, countryOfOrigin: String) {
        self.name = name
        self.year = year
        self.countryOfOrigin = countryOfOrigin
    }
}
class Cruiseship: Ship {       // subclass
    let maxcapacity : Int = 100
    let oceanOfOperation: String
    var currentPassengerCount: Int = 50
    
    init(maxcapacity: Int, oceanOfOperation: String, currentPassengerCount: Int) {
        self.maxcapacity = maxcapacity
        self.oceanOfOperation = oceanOfOperation
        self.currentPassengerCount = currentPassengerCount
}
    
    func addPassenger() {
        if currentPassengerCount < maxcapacity {
            currentPassengerCount = 50 + 1
            passengerCount()
            print("Passenger added . Current passenger:  \(currentPassengerCount)")
        }else {
            print("The ship is at max passenger capacity")
            
        }
        
        func passengerCount() {
            print("Current passenger count: \(currentPassengerCount)")
        }
    }


        class CargoShip: Ship {   // subclass
            let maxCargoCapacity: Int = 10
            var currentCargoCount: Int = 3
            let isInternational: Bool
            
            init(currentCargoCount: Int, isInternational: Bool) {
                self.currentCargoCount = currentCargoCount
                self.isInternational = isInternational
            }
        
    
    
        func addCargo() {
            if currentCargoCount < maxCargoCapacity {
                currentCargoCount = 3 + 1
                print("Cargo added . Current cargo count :  \(currentCargoCount)")
            }else {
                print("The ship is at max cargo capacity ")
            }
        
            func cargoCount() {
                print("Current cargo count: \(currentCargoCount)")
                
                
                
                class Pirateship: Ship {
                    let maxTreasureCapacity: Int
                    var currentTreasureCount: Int = 1
                    let numberOfCannos: Int
                    
                    init(maxTreasureCapacity: Int, currentTreasureCount: Int, numberOfCannos: Int) {
                        self.maxTreasureCapacity = maxTreasureCapacity
                        self.currentTreasureCount = currentTreasureCount
                        self.numberOfCannos = numberOfCannos
                    }
                    
                    func addTreasure() {
                        if currentTreasureCount < maxTreasureCapacity {
                            currentTreasureCount = 1 + 1
                            print("Treasure added . Current treasure count :  \(currentTreasureCount)")
                        }else {
                            print("The ship is at max treasure capacity")
                        }
                    }
                    
                    func TresureCount() {
                        print("Current tresure count: \(currentTreasureCount)")
                    }
                }
                
        
                    
                    
                

